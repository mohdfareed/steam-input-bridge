Source: https://www.traceparts.com/en/product/dongguan-alpsr-electronic-xbu25104xn-micro-usb-malemicro-connectorusb-micro-socketmicro-socketmicro-interfacemicro-usb?Product=90-26052023-026782
