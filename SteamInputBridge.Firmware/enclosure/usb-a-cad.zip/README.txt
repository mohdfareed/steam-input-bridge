Source: https://www.traceparts.com/en/product/edac-inc-usb-typea-cable-end-connector-691c104290120?CatalogPath=EDAC_845009307%3AF_EDAC.060A.020.010.010.010&Product=90-29032021-052020
